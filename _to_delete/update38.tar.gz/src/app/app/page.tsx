import { redirect } from "next/navigation";

export default function AppHome() {
  redirect("/app/shows");
}
