import { loadLibrary } from "@/lib/library";
import { isFavorite, labelFor, movieSections, orderedMovies, year } from "@/lib/archive";
import { EmptyLibrary } from "@/components/EmptyLibrary";
import { Poster } from "@/components/Poster";
import Link from "next/link";
import { SyncedLine } from "@/components/SyncedLine";

export default async function Movies() {
  const { row } = await loadLibrary();
  if (!row) return <EmptyLibrary />;

  const archive = row.archive;
  const movies = orderedMovies(archive);

  return (
    <>
      <div className="flex justify-end">
        <SyncedLine row={row} />
      </div>

      {movieSections.map((status) => {
        const run = movies.filter((m) => m.status === status);
        if (run.length === 0) return null;
        return (
          <section key={status} className="mt-10">
            <div className="rule" />
            <div className="eyebrow">
              {labelFor(status)} · {run.length}
            </div>
            <div className="grid gap-4 [grid-template-columns:repeat(auto-fill,minmax(130px,1fr))]">
              {run.map(({ movie }) => {
                const fav = isFavorite(archive, `movie:${movie.id}`);
                const watchedOn = archive.movieWatchedDates?.[String(movie.id)];
                return (
                  <Link key={movie.id} href={`/movie/${movie.id}`} className="block no-underline text-ink">
                    <Poster path={movie.poster_path} alt={movie.title} />
                    <div className="mt-2 text-sm font-semibold leading-tight">
                      {fav && <span className="text-movies mr-1" aria-label="Favorite">♥</span>}
                      {movie.title}
                    </div>
                    <div className="text-xs text-dim">
                      {year(movie.release_date)}
                      {watchedOn && ` · seen ${watchedOn.slice(0, 10)}`}
                    </div>
                  </Link>
                );
              })}
            </div>
          </section>
        );
      })}
    </>
  );
}
