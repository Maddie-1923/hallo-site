import { loadLibrary } from "@/lib/library";
import { EmptyLibrary } from "@/components/EmptyLibrary";
import { Poster } from "@/components/Poster";

export default async function Profile() {
  const { row } = await loadLibrary();
  if (!row) return <><h1 className="!text-[clamp(44px,8vw,72px)]">Profile</h1><EmptyLibrary /></>;

  const a = row.archive;
  const reactions = a.reactions ?? {};
  const lovedShows = a.shows.filter((s) => reactions[`show:${s.show.id}`] === "loved");
  const lovedMovies = a.movies.filter((m) => reactions[`movie:${m.movie.id}`] === "loved");
  const ratings = Object.values(a.ratings ?? {});
  const avg = ratings.length ? (ratings.reduce((x, y) => x + y, 0) / ratings.length).toFixed(1) : null;
  const lists = a.customLists ?? [];
  const order = a.customListOrder ?? [];
  const rank = new Map(order.map((id, i) => [id, i]));
  const sortedLists = [...lists].sort((x, y) => (rank.get(x.id) ?? 1e9) - (rank.get(y.id) ?? 1e9));
  const showByID = new Map(a.shows.map((s) => [s.show.id, s.show]));
  const movieByID = new Map(a.movies.map((m) => [m.movie.id, m.movie]));

  const tiles = [
    ["Shows", a.shows.length],
    ["Movies", a.movies.length],
    ["Episodes", a.watched.length],
    ["Films seen", a.watchedMovies?.length ?? a.movies.filter((m) => m.status === "Watched").length],
    ["Ratings", ratings.length],
    ["Average", avg ?? "—"],
  ] as const;

  return (
    <div className="wrap py-10">
      <h1 className="!text-[clamp(44px,8vw,72px)]">Profile</h1>
      <div className="grid gap-3 mt-8 [grid-template-columns:repeat(auto-fit,minmax(140px,1fr))]">
        {tiles.map(([label, value]) => (
          <div key={label} className="card !p-5">
            <div className="display text-4xl leading-none">{value}</div>
            <div className="text-xs text-dim mt-1 uppercase tracking-[.12em]">{label}</div>
          </div>
        ))}
      </div>

      {(lovedShows.length > 0 || lovedMovies.length > 0) && (
        <section className="mt-12">
          <div className="rule" />
          <div className="eyebrow">Favorites · {lovedShows.length + lovedMovies.length}</div>
          <div className="grid gap-4 [grid-template-columns:repeat(auto-fill,minmax(110px,1fr))]">
            {lovedShows.map(({ show }) => (
              <div key={`s${show.id}`}>
                <Poster path={show.poster_path} alt={show.name} />
                <div className="mt-2 text-xs font-semibold leading-tight">{show.name}</div>
              </div>
            ))}
            {lovedMovies.map(({ movie }) => (
              <div key={`m${movie.id}`}>
                <Poster path={movie.poster_path} alt={movie.title} />
                <div className="mt-2 text-xs font-semibold leading-tight">{movie.title}</div>
              </div>
            ))}
          </div>
        </section>
      )}

      {sortedLists.map((list) => {
        const items = [
          ...(list.showIDs ?? []).map((id) => showByID.get(id)).filter(Boolean).map((s) => ({ key: `s${s!.id}`, path: s!.poster_path, name: s!.name })),
          ...(list.movieIDs ?? []).map((id) => movieByID.get(id)).filter(Boolean).map((m) => ({ key: `m${m!.id}`, path: m!.poster_path, name: m!.title })),
        ];
        return (
          <section key={list.id} className="mt-12">
            <div className="rule" />
            <div className="eyebrow">{list.name} · {items.length}</div>
            {list.detail && <p className="text-dim text-[15px] -mt-2 mb-4">{list.detail}</p>}
            <div className="grid gap-4 [grid-template-columns:repeat(auto-fill,minmax(110px,1fr))]">
              {items.map((it) => (
                <div key={it.key}>
                  <Poster path={it.path} alt={it.name} />
                  <div className="mt-2 text-xs font-semibold leading-tight">{it.name}</div>
                </div>
              ))}
            </div>
          </section>
        );
      })}
    </div>
  );
}
