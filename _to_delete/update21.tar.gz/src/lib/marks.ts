import type { LibraryArchive } from "./archive";
import type { MarkState } from "@/components/MarkButtons";

// What the heart and the watched mark should show for a title, read off the
// archive: loved is the reaction, watched is Watched for a film and Watching
// for a show.
export function markLookup(archive: LibraryArchive | null) {
  const reactions = archive?.reactions ?? {};
  const shows = new Map(archive?.shows.map((t) => [t.show.id, t.status]) ?? []);
  const movies = new Map(archive?.movies.map((t) => [t.movie.id, t.status]) ?? []);
  return {
    show: (id: number): MarkState => ({ loved: reactions[`show:${id}`] === "loved", watched: shows.get(id) === "Watching" }),
    movie: (id: number): MarkState => ({ loved: reactions[`movie:${id}`] === "loved", watched: movies.get(id) === "Watched" }),
  };
}
