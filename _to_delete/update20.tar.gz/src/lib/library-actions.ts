"use server";

import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { CURRENT_VERSION, isArchive, type LibraryArchive, type Movie, type MovieStatus, type Show, type WatchStatus } from "./archive";

// Every change the website makes to a library goes through here, and each one
// follows the rules the app's merge relies on: the record that changed gets a
// fresh `modified`, a removal leaves a tombstone, an episode's checkbox moves
// its `watchedStamps` entry, and the row's `changed_at` moves so the phone's
// three-way comparison sees that the other side moved. Get any of those wrong
// and the next sync from a phone quietly undoes what was done here.

const DEVICE = "Kodigo web";

// Swift's .iso8601 decoder refuses fractional seconds, so `toISOString()` as
// it comes would make the whole archive undecodable on the phone.
function now() {
  return new Date().toISOString().replace(/\.\d{3}Z$/, "Z");
}

function emptyArchive(): LibraryArchive {
  return {
    version: CURRENT_VERSION,
    exported: now(),
    device: DEVICE,
    shows: [],
    movies: [],
    watched: [],
    watchedMovies: [],
    movieWatchedDates: {},
    watchedDates: {},
    watchedStamps: {},
    showTombstones: [],
    movieTombstones: [],
  };
}

async function withArchive(mutate: (a: LibraryArchive, stamp: string) => void): Promise<{ error?: string }> {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return { error: "Sign in to track titles." };

  const { data } = await supabase.from("libraries").select("archive").eq("user_id", user.id).maybeSingle();
  const archive: LibraryArchive = data && isArchive(data.archive) ? (data.archive as LibraryArchive) : emptyArchive();

  const stamp = now();
  mutate(archive, stamp);
  archive.exported = stamp;
  archive.device = DEVICE;

  const { error } = await supabase.from("libraries").upsert({
    user_id: user.id,
    archive,
    version: archive.version,
    changed_at: stamp,
    device: DEVICE,
  });
  if (error) return { error: error.message };
  revalidatePath("/app", "layout");
  return {};
}

function dropTombstone(list: { id: number; removed: string }[] | undefined, id: number) {
  return (list ?? []).filter((t) => t.id !== id);
}

// ---- Shows ----

export async function trackShow(show: Show, status: WatchStatus = "Watching") {
  return withArchive((a, stamp) => {
    const existing = a.shows.find((s) => s.show.id === show.id);
    if (existing) {
      existing.status = status;
      existing.modified = stamp;
    } else {
      a.shows.push({ show, status, modified: stamp, added: stamp });
    }
    // Re-adding a show the tombstone still remembers has to clear it, or the
    // merge reads "removed after the add" and takes it straight back out.
    a.showTombstones = dropTombstone(a.showTombstones, show.id);
  });
}

export async function untrackShow(id: number) {
  return withArchive((a, stamp) => {
    a.shows = a.shows.filter((s) => s.show.id !== id);
    a.showTombstones = [...dropTombstone(a.showTombstones, id), { id, removed: stamp }];
  });
}

export async function setEpisodeWatched(showID: number, season: number, episode: number, watched: boolean) {
  const key = `${showID}-${season}-${episode}`;
  return withArchive((a, stamp) => {
    const set = new Set(a.watched);
    a.watchedDates ??= {};
    a.watchedStamps ??= {};
    if (watched) {
      set.add(key);
      // First viewing date is never rewritten — the app's rule, kept here.
      a.watchedDates[key] ??= stamp;
    } else {
      set.delete(key);
      delete a.watchedDates[key];
    }
    // The stamp moves either way. Present in stamps and absent from watched is
    // how an uncheck survives a merge.
    a.watchedStamps[key] = stamp;
    a.watched = [...set];
    const tracked = a.shows.find((s) => s.show.id === showID);
    if (tracked) tracked.modified = stamp;
  });
}

// ---- Movies ----

export async function trackMovie(movie: Movie, status: MovieStatus = "To Watch") {
  return withArchive((a, stamp) => {
    const existing = a.movies.find((m) => m.movie.id === movie.id);
    if (existing) {
      existing.status = status;
      existing.modified = stamp;
    } else {
      a.movies.push({ movie, status, modified: stamp, added: stamp });
    }
    a.movieTombstones = dropTombstone(a.movieTombstones, movie.id);
    a.watchedMovies ??= [];
    a.movieWatchedDates ??= {};
    if (status === "Watched") {
      if (!a.watchedMovies.includes(movie.id)) a.watchedMovies.push(movie.id);
      a.movieWatchedDates[String(movie.id)] ??= stamp;
    }
  });
}

export async function untrackMovie(id: number) {
  return withArchive((a, stamp) => {
    a.movies = a.movies.filter((m) => m.movie.id !== id);
    a.movieTombstones = [...dropTombstone(a.movieTombstones, id), { id, removed: stamp }];
  });
}
