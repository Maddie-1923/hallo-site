"use client";

import Link from "next/link";
import { useEffect, useLayoutEffect, useRef, useState, useTransition } from "react";
import { createPortal } from "react-dom";
import { useRouter } from "next/navigation";
import type { Movie, Show } from "@/lib/archive";
import type { ListOption } from "@/lib/marks";
import { createList, setOnList, setRating, trackMovie, trackShow, untrackMovie, untrackShow } from "@/lib/library-actions";
import type { MarkState } from "./MarkButtons";

type Target = { kind: "show"; show: Show } | { kind: "movie"; movie: Movie };

// The panel behind the list mark — Letterboxd's "•••" in Kodigo's words. A
// rating row out of ten, then: save it for later, put it on a list (the
// person's own lists, and a field to start one), open the page, and take it
// out of the library. Everything writes through the same actions the app's
// merge understands.
export function MarkMenu({
  target,
  state,
  lists,
  onClose,
  anchor,
}: {
  target: Target;
  state: MarkState;
  lists: ListOption[];
  onClose: () => void;
  /** The button the menu hangs off. Rendered in a portal, positioned from its rect, so no rail or card can clip it. */
  anchor: HTMLElement | null;
}) {
  const router = useRouter();
  const root = useRef<HTMLDivElement>(null);
  const [pending, start] = useTransition();
  const [error, setError] = useState<string>();
  const [showLists, setShowLists] = useState(false);
  const [newName, setNewName] = useState("");
  const [rating, setRatingShown] = useState<number | null>(state.rating);
  const [onLists, setOnLists] = useState<Set<string>>(new Set(state.listIDs));
  const [hover, setHover] = useState<number | null>(null);
  const title = target.kind === "show" ? target.show.name : target.movie.title;
  const href = target.kind === "show" ? `/show/${target.show.id}` : `/movie/${target.movie.id}`;
  const [pos, setPos] = useState<{ top?: number; bottom?: number; right: number } | null>(null);

  // Above the button when there's room, below when there isn't; right-aligned
  // to it. Re-measured on scroll and resize so it stays attached.
  useLayoutEffect(() => {
    if (!anchor) return;
    const place = () => {
      const r = anchor.getBoundingClientRect();
      const right = Math.max(8, window.innerWidth - r.right);
      if (r.top > 360) setPos({ bottom: window.innerHeight - r.top + 8, right });
      else setPos({ top: r.bottom + 8, right });
    };
    place();
    window.addEventListener("scroll", place, true);
    window.addEventListener("resize", place);
    return () => {
      window.removeEventListener("scroll", place, true);
      window.removeEventListener("resize", place);
    };
  }, [anchor]);

  useEffect(() => {
    const onDown = (e: MouseEvent) => {
      if (!root.current?.contains(e.target as Node)) onClose();
    };
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    document.addEventListener("mousedown", onDown);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onDown);
      document.removeEventListener("keydown", onKey);
    };
  }, [onClose]);

  function run(action: () => Promise<{ error?: string }>, after?: () => void) {
    setError(undefined);
    start(async () => {
      const r = await action();
      if (r.error) {
        if (r.error.startsWith("Sign in")) {
          router.push(`/login?next=${encodeURIComponent(window.location.pathname)}`);
          return;
        }
        setError(r.error);
        return;
      }
      after?.();
      router.refresh();
    });
  }

  const row = "w-full text-left px-4 py-2.5 text-sm hover:bg-card-hi cursor-pointer disabled:opacity-50 disabled:cursor-default text-ink no-underline block";

  if (!pos || typeof document === "undefined") return null;
  return createPortal(
    <div
      ref={root}
      role="menu"
      aria-label={`More for ${title}`}
      onClick={(e) => {
        e.stopPropagation();
      }}
      style={{ position: "fixed", ...pos }}
      className="z-[70] w-[260px] rounded-2xl border border-hair bg-card shadow-[0_20px_50px_rgba(0,0,0,.6)] overflow-hidden text-left font-normal"
    >
      {/* Rating: ten pips. Hover previews, click sets, clicking the current
          score clears it. */}
      <div className="px-4 pt-3 pb-2 border-b border-hair">
        <div className="text-[11px] font-bold tracking-[.14em] uppercase text-dim mb-2">Rate it{rating ? ` · ${rating}/10` : ""}</div>
        <div className="flex gap-1" onMouseLeave={() => setHover(null)}>
          {Array.from({ length: 10 }, (_, i) => i + 1).map((n) => {
            const lit = n <= (hover ?? rating ?? 0);
            return (
              <button
                key={n}
                type="button"
                aria-label={`${n} out of 10`}
                onMouseEnter={() => setHover(n)}
                disabled={pending}
                onClick={() => {
                  const next = rating === n ? null : n;
                  setRatingShown(next);
                  run(() => setRating(target, next));
                }}
                className="flex-1 h-5 rounded-sm transition-colors cursor-pointer"
                style={{ background: lit ? "var(--accent-fill)" : "color-mix(in srgb, var(--ink) 15%, transparent)" }}
              />
            );
          })}
        </div>
      </div>

      {!state.tracked && (
        <button
          type="button"
          className={row}
          disabled={pending}
          onClick={() => run(() => (target.kind === "movie" ? trackMovie(target.movie, "To Watch") : trackShow(target.show, "Watching")), onClose)}
        >
          Save for later
        </button>
      )}

      <button type="button" className={`${row} flex items-center justify-between`} onClick={() => setShowLists((v) => !v)} aria-expanded={showLists}>
        <span>Put on a list…</span>
        <span className="text-dim text-xs">{showLists ? "▴" : "▾"}</span>
      </button>
      {showLists && (
        <div className="px-3 pb-3 bg-card-hi/60">
          {lists.length === 0 && <p className="text-xs text-dim px-1 pt-2 m-0">No lists yet. Start one below.</p>}
          <ul className="m-0 p-0 list-none">
            {lists.map((l) => {
              const on = onLists.has(l.id);
              return (
                <li key={l.id}>
                  <label className="flex items-center gap-2 px-1 py-1.5 text-sm cursor-pointer">
                    <input
                      type="checkbox"
                      className="accent-[var(--accent-fill)]"
                      checked={on}
                      disabled={pending}
                      onChange={(e) => {
                        const next = e.target.checked;
                        setOnLists((s) => {
                          const c = new Set(s);
                          if (next) c.add(l.id);
                          else c.delete(l.id);
                          return c;
                        });
                        run(() => setOnList(l.id, target, next));
                      }}
                    />
                    <span className="truncate">{l.name}</span>
                  </label>
                </li>
              );
            })}
          </ul>
          <form
            className="flex gap-1.5 mt-1"
            onSubmit={(e) => {
              e.preventDefault();
              const name = newName.trim();
              if (!name) return;
              run(
                async () => {
                  const r = await createList(name);
                  if (r.error || !r.id) return { error: r.error ?? "Couldn't make the list." };
                  return setOnList(r.id, target, true);
                },
                () => setNewName(""),
              );
            }}
          >
            <input className="field !py-1.5 !px-2.5 text-sm" placeholder="New list…" value={newName} maxLength={60} onChange={(e) => setNewName(e.target.value)} />
            <button type="submit" className="btn !py-1.5 !px-3 text-sm" disabled={pending || !newName.trim()}>Add</button>
          </form>
        </div>
      )}

      <Link href={href} className={row} onClick={onClose}>
        Open the page
      </Link>

      {state.tracked && (
        <button
          type="button"
          className={`${row} border-t border-hair`}
          style={{ color: "var(--movies)" }}
          disabled={pending}
          onClick={() => run(() => (target.kind === "movie" ? untrackMovie(target.movie.id) : untrackShow(target.show.id)), onClose)}
        >
          Take it out of your lists
        </button>
      )}

      {error && <p className="px-4 pb-3 text-xs m-0" style={{ color: "var(--movies)" }} role="alert">{error}</p>}
    </div>,
    document.body,
  );
}
