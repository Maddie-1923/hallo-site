import { loadLibrary } from "@/lib/library";
import { episodesWatched, isFavorite, labelFor, orderedShows, showSections, year } from "@/lib/archive";
import { EmptyLibrary } from "@/components/EmptyLibrary";
import { Poster } from "@/components/Poster";
import Link from "next/link";

export default async function Shows() {
  const { row } = await loadLibrary();
  if (!row) return <EmptyLibrary />;

  const archive = row.archive;
  const shows = orderedShows(archive);

  return (
    <>
      {showSections.map((status) => {
        const run = shows.filter((s) => s.status === status);
        if (run.length === 0) return null;
        return (
          <section key={status} className="mt-10">
            <div className="rule" />
            <div className="eyebrow">
              {labelFor(status)} · {run.length}
            </div>
            <div className="grid gap-4 [grid-template-columns:repeat(auto-fill,minmax(130px,1fr))]">
              {run.map(({ show }) => {
                const seen = episodesWatched(archive, show.id);
                const fav = isFavorite(archive, `show:${show.id}`);
                return (
                  <Link key={show.id} href={`/show/${show.id}`} className="block no-underline text-ink">
                    <Poster path={show.poster_path} alt={show.name} />
                    <div className="mt-2 text-sm font-semibold leading-tight">
                      {fav && <span className="text-movies mr-1" aria-label="Favorite">♥</span>}
                      {show.name}
                    </div>
                    <div className="text-xs text-dim">
                      {year(show.first_air_date)}
                      {seen > 0 && ` · ${seen} ep${seen === 1 ? "" : "s"}`}
                    </div>
                  </Link>
                );
              })}
            </div>
          </section>
        );
      })}
    </>
  );
}
