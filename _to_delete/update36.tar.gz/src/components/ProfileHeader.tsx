import { image } from "@/lib/tmdb";
import type { LibraryArchive } from "@/lib/archive";
import type { Profile } from "@/lib/profile";
import { EditProfile } from "./EditProfile";

// The Letterboxd-style top of My Lists: a banner the person picked from their
// own library, an avatar that's a poster, their name, and four numbers. The
// banner bleeds to the page edges; everything under it sits in the wrap.
export function ProfileHeader({ profile, archive, email }: { profile: Profile; archive: LibraryArchive | null; email: string }) {
  // Full width on every screen, so this is the one image worth the original.
  const banner = image.banner(profile.banner_path);
  const avatar = image.poster(profile.avatar_path, "w185");
  const name = profile.display_name || email.split("@")[0];
  const initial = (name[0] ?? "?").toUpperCase();

  const year = String(new Date().getFullYear());
  const shows = archive?.shows.length ?? 0;
  const movies = archive?.movies.length ?? 0;
  const episodes = archive?.watched.length ?? 0;
  const thisYear =
    Object.values(archive?.watchedDates ?? {}).filter((d) => d.startsWith(year)).length +
    Object.values(archive?.movieWatchedDates ?? {}).filter((d) => d.startsWith(year)).length;

  // What the picker can offer: every backdrop and poster the library holds.
  const backdrops = [
    ...(archive?.shows.map((t) => ({ path: t.show.backdrop_path, title: t.show.name })) ?? []),
    ...(archive?.movies.map((t) => ({ path: t.movie.backdrop_path, title: t.movie.title })) ?? []),
  ].filter((b): b is { path: string; title: string } => !!b.path);
  const posters = [
    ...(archive?.shows.map((t) => ({ path: t.show.poster_path, title: t.show.name })) ?? []),
    ...(archive?.movies.map((t) => ({ path: t.movie.poster_path, title: t.movie.title })) ?? []),
  ].filter((p): p is { path: string; title: string } => !!p.path);

  return (
    <header>
      {/* The banner is a ratio rather than a fixed band, so every screen keeps
          the same share of the picture instead of cropping a 340px strip out
          of whatever the window happens to be. Wider screens get a shallower
          ratio because a 3:1 crop of a 16:9 backdrop is already most of what
          the picture has; the vh cap stops an ultrawide monitor turning the
          banner into half the page. */}
      <div className="relative overflow-hidden aspect-[2/1] sm:aspect-[2.5/1] lg:aspect-[3/1] max-h-[45vh]">
        {banner ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={banner} alt="" aria-hidden // Slightly above centre: on a 16:9 backdrop squeezed into 3:1 that lands
            // on faces, where pinning the top cut them off.
            className="absolute inset-0 w-full h-full object-cover object-[50%_35%]" />
        ) : (
          <div aria-hidden className="absolute inset-0" style={{ background: "linear-gradient(135deg, color-mix(in srgb, var(--accent-fill) 35%, var(--page)), var(--page))" }} />
        )}
        <div aria-hidden className="absolute inset-0" style={{ background: "linear-gradient(180deg, color-mix(in srgb, var(--page) 20%, transparent) 0%, color-mix(in srgb, var(--page) 0%, transparent) 40%, color-mix(in srgb, var(--page) 85%, transparent) 85%, var(--page) 100%)" }} />
      </div>

      <div className="wrap relative -mt-16 flex flex-wrap items-end gap-6">
        <div className="w-[104px] h-[104px] rounded-full overflow-hidden border-4 border-page bg-card shrink-0 shadow-[0_8px_24px_rgba(0,0,0,.4)]">
          {avatar ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={avatar} alt="" className="w-full h-full object-cover" />
          ) : (
            <div className="w-full h-full flex items-center justify-center display text-5xl bg-accent-fill text-graphite">{initial}</div>
          )}
        </div>
        <div className="min-w-0 pb-2">
          <h1 className="!text-[clamp(36px,6vw,56px)] leading-none truncate">{name}</h1>
          <p className="text-sm text-dim m-0 mt-1">My Lists</p>
        </div>
        <div className="ml-auto flex items-center gap-6 pb-3 flex-wrap">
          <Stat n={shows} label="Shows" />
          <Stat n={movies} label="Films" />
          <Stat n={episodes} label="Episodes" />
          <Stat n={thisYear} label="This year" />
          <EditProfile profile={profile} backdrops={backdrops} posters={posters} fallbackName={name} />
        </div>
      </div>
    </header>
  );
}

function Stat({ n, label }: { n: number; label: string }) {
  return (
    <div className="text-center">
      <div className="display text-3xl leading-none">{n.toLocaleString()}</div>
      <div className="text-[10px] font-bold tracking-[.14em] uppercase text-dim mt-1">{label}</div>
    </div>
  );
}
