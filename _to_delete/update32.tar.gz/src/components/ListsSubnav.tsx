"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

// The second row under "My Lists": which slice of the library is showing.
const tabs = [
  ["/app/shows", "Shows"],
  ["/app/movies", "Movies"],
];

export function ListsSubnav() {
  const path = usePathname();
  return (
    <div className="flex gap-1 p-1 rounded-full border border-hair bg-card self-start mt-6">
      {tabs.map(([href, label]) => {
        const on = path.startsWith(href);
        return (
          <Link
            key={href}
            href={href}
            className={`px-4 py-1.5 rounded-full text-sm font-semibold no-underline ${
              on ? "bg-accent-fill text-graphite" : "text-dim hover:text-ink"
            }`}
            aria-current={on ? "page" : undefined}
          >
            {label}
          </Link>
        );
      })}
    </div>
  );
}
